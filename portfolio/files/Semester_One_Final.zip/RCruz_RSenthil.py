import PIL
import os.path  
import PIL.ImageDraw
import numpy

def gray_scale(original_image):
    '''GRAY SCALE'''    
    width, height = original_image.size #Finds size of image, so the for loop can iterate through each pixel
    original_image = original_image.convert('RGBA') #Converts to RGBA mode, so we can add 255 to alpha channel so gray is opaque
    img = numpy.array(original_image) # creates and array so we can edit the individual pixels
    for r in range(height):
        for c in range(width):
            gray = int((0.2989*img[r][c][0]+0.587*img[r][c][1]+0.114*img[r][c][2])) #This formula is for converting to weighted grayscale (not true scale)
            img[r][c] = [gray,gray,gray,255] #replaces all the of the color values with the gray value calculated, and adds 255 to make sure gray is opaque
    image = PIL.Image.fromarray(img) #converts back to image
    return image     

def white_border(original_image):
    '''FOR WHITE BORDER'''
    width, height = original_image.size #Gets the size of the image in order to create the border
    wide = int(0.1 * float(min(width, height))) #Sets the width for the border to be 10% the width of the image 
    #start with transparent mask
    border_mask = PIL.Image.new('RGBA', (width, height), (0,0,0,0)) 
    drawing_layer = PIL.ImageDraw.Draw(border_mask)
    
    # Draw the inside of the picture (part which does not get border)
    drawing_layer.polygon([(wide, wide),(wide, height-wide),(width-wide, height-wide), (width-wide, wide)],
                            fill=(255,255,255))
    
    # Make the new image, starting with all transparent
    result = PIL.Image.new('RGBA', original_image.size, (255,255,255))
    result.paste(original_image, (0,0), mask=border_mask)    
    return result #returns the picture with the border for it to be saved in alter_all_images()
 
def black_border(original_image):
    '''FOR BLACK BORDER'''
    width, height = original_image.size #gets the width and height, so can be used for drawing the border
    wide = int(0.07 * float(min(width, height))) #sets the width for the black border to be 7% the width of the image
     #start with transparent mask
    border_mask = PIL.Image.new('RGBA', (width, height), (0,0,0,0))
    drawing_layer = PIL.ImageDraw.Draw(border_mask)
    # Draw the inside of the picture (part which does not get border)
    drawing_layer.polygon([(wide, wide),(wide, height-wide),(width-wide, height-wide), (width-wide, wide)],
                            fill=(0,0,0))
    
    # Make the new image, starting with all transparent
    result = PIL.Image.new('RGBA', original_image.size, (0,0,0))
    result.paste(original_image, (0,0), mask=border_mask)
    return result #returns the picture with a black border for it to be saved in alter_all_images()
    
def blend(original_image, directory):
    '''FOR TRANSPARENT HAND'''
    width, height = original_image.size #finds size of the original image; used later to resize the image being blended with original
    hopeless_directory = os.path.join(directory, 'hopeless') #finds the image being blended (this picture is consistent with each edit; no matter the original picture)
    hopeless_image = PIL.Image.open(hopeless_directory + '\\hand.png')#https://www.flickr.com/photos/david_spigolon/134789129/ IMAGE CREDIT: David Spigolon
    hopeless_image = hopeless_image.resize((width, height)) #resizes the blended image to the size of the original image, so we can blend the two images.
    hopeless_image = hopeless_image.convert('RGBA') #converts to RGBA for consistency
    transparent_arm = PIL.Image.blend(hopeless_image, original_image, 0.7) #finally blends the picture
    return transparent_arm
    #Spigolon, D. (n.d.). Hopeless. Retrieved December 13, 2016, from https://www.flickr.com/photos/david_spigolon/134789129/
def signature(original_image, directory):
    '''FOR ADDING SIGNATURES'''
    width_original, height_original = original_image.size  #gets the width and height of the lastly edited image, so the signature can be proportional 
    signature_directory = os.path.join(directory, 'signature') #sets variable to be the signature folder directory 
    signature_image = PIL.Image.open(signature_directory + '\\signature.png') #opens the signature pciture
    width_signature, height_signature = signature_image.size #gets the width and height of the signature picture to make the sinature proportional 
    original_image = original_image.convert('RGBA') #converts the edited picture to RGBA mode 
    signature_image = signature_image.convert('RGBA') #converts the signature picture to RGBA mode 
    img = numpy.array(signature_image) #converts the signature image into an array 
    for r in range(height_signature): #iterates through the height pixels for the signature image
        for c in range(width_signature): #iterates through the width pixels for the sinature image
            if sum(img[r][c])>765: #only modifies pixels that are white
                img[r][c] = [255,255,255,0] #makes the pixels transparent 
    for r in range(height_signature): #iterates through the height pixels for the signature image 
        for c in range(width_signature): #iterates through the width pixels for the sinature image
            if sum(img[r][c])<765: #only modifies pixels that are black
                img[r][c] = [255,255,255,255] #makes the black pixels white 
    signature_image = PIL.Image.fromarray(img) #converts the array back into an image 
    height = int(0.07*float(min(width_original, height_original))) #sets height for the signature to be 7% of the minimum chossing between the edited image's width or height
    width = int(height*(398/45)) #sets width for the signature to be 884% of the height
    signature_image = signature_image.resize((width, height)) #resizes the signature to the new width and height 
    width_signature, height_signature = signature_image.size #gets the width and height of the new resized signature image
    original_image.paste(signature_image, (width_original-width_signature, height_original-height_signature), mask=signature_image) #pastes the signature onto the edited image
    return original_image
    

def get_images(directory=None):
    '''GETS IMAGES FROM DIRECTORY - CODE COPIED FROM FUNCTION 'get_images' obtained from LESSON 1.4.5 IMAGE ALGORITHMS'''
    if directory == None:
        directory = os.getcwd() # Use working directory if unspecified
        
    image_list = [] # Initialize aggregaotrs
    file_list = []
    
    directory_list = os.listdir(directory) # Get list of files to be edited
    for entry in directory_list:
        absolute_filename = os.path.join(directory, entry) #finds absolute filename to open picture
        try:
            image = PIL.Image.open(absolute_filename)
            file_list += [entry] #adds to list
            image_list += [image]
        except IOError:
            pass # do nothing with errors tying to open non-images
    return image_list, file_list
    #get_images function source: MyPLTW. (n.d.). Retrieved December 14, 2016, from https://pltw.instructure.com
def alter_all_images(directory = None):
    if directory == None:
    
    #to choose which function to use        
        directory = os.getcwd() # Use working directory if unspecified
    
    
    '''GRAYSCALE'''
    # Create a new directory 'grayscale'
    grayscale_directory = os.path.join(directory, 'grayscale')
    try:
        os.mkdir(grayscale_directory)
    except OSError:
        pass # if the directory already exists, proceed  
    
    #load all the images
    image_list, file_list = get_images(directory)  
    #go through the images and save modified versions
    for n in range(len(image_list)):
        # Parse the filename
        filename, filetype = os.path.splitext(file_list[n])
        '''ALTERING IMAGE HERE'''
        #Converting to Grayscale
        new_image = gray_scale(image_list[n]) #runs grayscale function
        new_image_filename = os.path.join(grayscale_directory, filename + '_gray_scale' + '.png')
        new_image.save(new_image_filename) #saves the grayscale image in the grayscale folder under images (adds '_gray_scale' to name, to keep track of images)
    '''WHITE BORDER'''
    # Create a new directory 'white_border'
    white_border_directory = os.path.join(directory, 'white_border')
    try:
        os.mkdir(white_border_directory)
    except OSError:
        pass
    image_list, file_list = get_images(grayscale_directory) #gets images from the grayscale directory (so that the images can be edited on top of eachother) 
    for n in range(len(image_list)):
        filename, filetype = os.path.splitext(file_list[n])
        #adding white border
        new_image = white_border(image_list[n]) #runs the function to add white border to the picture
        new_image_filename = os.path.join(white_border_directory, filename + '_white_border' + '.png')
        new_image.save(new_image_filename) #saves white border under white_border directory (adds '_white_border' to name, to keep track of images)
    
    
    '''BLACK BORDER'''
    # Create a new directory 'black_border'
    black_border_directory = os.path.join(directory, 'black_border')
    try:
        os.mkdir(black_border_directory)
    except OSError:
        pass
    image_list, file_list = get_images(white_border_directory) #gets images from the white_border_directory, so that we can add the new border ot the images
    for n in range(len(image_list)):
        filename, filetype = os.path.splitext(file_list[n])
        new_image = black_border(image_list[n]) #runs function here
    
        #Saves black bordered picture later
        new_image_filename = os.path.join(black_border_directory, filename + '_black_border.png')
        new_image.save(new_image_filename) #saves black border under black_border directory (adds '_black_border' to name, to keep track of images)
    '''BLENDING PICTURES'''
    # Create a new directory 'blend'
    blend_directory = os.path.join(directory, 'blend')
    try:
        os.mkdir(blend_directory)
    except OSError:
        pass
    image_list, file_list = get_images(black_border_directory) #gets images from the black_border directory, so the image so far will have the new edit
    for n in range(len(image_list)):
        filename, filetype = os.path.splitext(file_list[n])
        new_image = blend(image_list[n], os.getcwd()) #runs function here
    
        #Saves black bordered picture later
        new_image_filename = os.path.join(blend_directory, filename + '_blend.png')
        new_image.save(new_image_filename) #saves blended image under blend directory (adds '_blend' to name, to keep track of images)
    '''SIGNATURES'''
    # Create a new directory 'Final'
    signature_directory = os.path.join(directory, 'Final')
    try:
        os.mkdir(signature_directory)
    except OSError:
        pass
    image_list, file_list = get_images(blend_directory) #gets images from the blend_directory to add the final edit; signatures
    for n in range(len(image_list)):
        filename, filetype = os.path.splitext(file_list[n])
        new_image = signature(image_list[n], os.getcwd()) #runs function here
    
        #Saves black bordered picture later
        new_image_filename = os.path.join(signature_directory, filename + '_signature.png')
        new_image.save(new_image_filename) #saves final image under Final directory with added '_signature' to the name
alter_all_images()