'''
***********************
*   Garrett Cargile   *
* Ramakrishna Senthil *
*    DATA  PROJECT    *
*       Period 2      *
***********************
'''


'''IMPORT STATEMENTS'''
import matplotlib.pyplot as plt
import os
import os.path
import numpy as np
from scipy.stats import linregress

'''FUNCTION DEFINITIONS'''
#Terrorist Attacks (ta)
def read_ta(filename): # Reads the Terrorist Attacks file and returns the number of terrorist attacks per year
    ta_file = open(filename)
    text_ta = ta_file.readlines()
    lines = text_ta[1:]
    year_list = []
    for date in lines:
        if '-' in date:
            year, month, day = date.split('-')
            year_list.append(int(year))
        elif '/' in date:
            month, day, year = date.split('/')
            year = year.split('\\')
            year_list.append(int(year[0]))


    year_count_list = []
    for i in range(len(year_list)-1):
        if int(year_list[i+1]) == int(year_list[i]):
            i += 1
        else:
            year_count = year_list.count(year_list[i])
            year_count_list.append(int(year_count))

    year_count_list.reverse() # The file starts at 2015 and ends at 2006, but we want it to start at 2006 and end at 2015
    return year_count_list

#Immigration (img)
def read_img(filename): # Reads the immigration file and returns a list with the total immigration numbers from each year
    img_file = open(filename)
    text_img = img_file.readlines()
    text_img = text_img[1:]
    img_count_list = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    for line in text_img:
        line = line.split(',')
        country = line[0]
        line = line[1:]
        if country == 'Iran':
            for i in range(10):
                count = int(line[i])
                img_count_list[i] = int(img_count_list[i]) + count
        elif country == 'Iraq':
            for i in range(10):
                count = int(line[i])
                img_count_list[i] = int(img_count_list[i]) + count
        elif country == 'Syria':
            for i in range(10):
                count = int(line[i])
                img_count_list[i] = int(img_count_list[i]) + count
        elif country == 'Yemen':
            for i in range(10):
                count = int(line[i])
                img_count_list[i] = int(img_count_list[i])+ count
        elif country == 'Sudan':
            for i in range(10):
                count = int(line[i])
                img_count_list[i] = int(img_count_list[i])+ count
        elif country == 'Somalia':
            for i in range(10):
                count = int(line[i])
                img_count_list[i] = int(img_count_list[i]) + count
    return img_count_list

def annotate(ax, line_one, p_value):
    '''Annotate an Axes with inferential stats

    line_one is a string to be printed first in the annotation
    '''
    # Print lines_one and p
    note = ax.text(0.5, 0.1, line_one + '\np=' + '%.2f'%p_value,
	            transform=ax.transAxes) # changes lowerleft coordinates of
	        # text to be Figure coordinates instead of Axes coordinates

	        # The '%.2f'%p is formattingstring%variables.
	        # The formattingstring is '%.2f' which takes a float and creates
	        # a string of digits followed by a decimal and two more digits.

    # Two dictionaries of matplotlib.patch.Patch properties
    # for p<0.5
    properties_yes = dict(boxstyle='round', facecolor='cyan', alpha=0.6)
    # for p>=0.5
    properties_no = dict(boxstyle='round', facecolor='white', alpha=0.6)
    # Set significant coorelations with these properties
    if p_value<0.05:
        note.set_bbox(properties_yes)
    else:
        note.set_bbox(properties_no)
    #FUNCTION 'annotate' USED FROM 'viz.py', created by (c) 2014 Project Lead The Way, Inc


'''VARIABLE DEFINITIONS'''

directory = os.path.dirname(os.path.abspath(__file__))
img_filename = os.path.join(directory, 'img.csv')
ta_filename = os.path.join(directory, 'ta.csv')
fig, ax = plt.subplots()

ydata = read_ta(ta_filename)
xdata = read_img(img_filename)

colors = ['red', 'white', 'blue']

'''MAIN FUNCTION'''

os.chdir(directory)

ax.set_xlabel('# of people immigrating from Muslim Countries (since 2006)')
ax.set_ylabel('# of Terrorist attacks (since 2006)')
fig.suptitle('Immigration from Muslim Countries to U.S. vs. # of Terrorist attacks in U.S.', fontsize=14, fontweight='bold')

plt.scatter(xdata, ydata, s = 30, c = colors, alpha=0.5)# Plotting the points
m, b, r, p, E = linregress(xdata, ydata)
xmin, xmax = ax.get_xlim()
x = np.linspace(xmin, xmax)
y = m*x + b # Finds y value from the equation generated from the linregress function
ax.plot(x, y, 'b-')# Plot best fit line

# Notate the linear correlation
stat_string = '$r^2$=' + str(int(r**2*100)) + '%'
annotate(ax, stat_string, p)

plt.show()# Shows the figure
